package com.example.victor.myapplication;

/**
 * Created by Victor on 02/04/2018.
 */

public class ModelAndroid {

    Connection conn = new Connection();

    private static ModelAndroid uniqueInstance;

    private ModelAndroid(){}

    public static ModelAndroid getInstance(){

        if(uniqueInstance == null){

            uniqueInstance = new ModelAndroid();

        }

        return uniqueInstance;

    }

    public Pesquisa getPesquisa(String nome, String ano, String geo) throws Exception {
        Pesquisa pesquisa = conn.sendGet(nome, ano, geo);
        return pesquisa;
    }

}
