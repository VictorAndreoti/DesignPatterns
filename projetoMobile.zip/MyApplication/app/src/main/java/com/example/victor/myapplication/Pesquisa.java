package com.example.victor.myapplication;

/**
 * Created by Victor on 04/04/2018.
 */

public class Pesquisa {

    private String vegnat;
    private String artif;

    public Pesquisa(String veg, String art){
        vegnat = veg;
        artif = art;
    }

    public String getVegnat() {return vegnat;}

    public String getArtif() {return artif;}
}
