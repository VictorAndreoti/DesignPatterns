package com.example.victor.myapplication;

/**
 * Created by Victor on 12/03/2018.
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.StrictMode;

public class Connection{

    private final String USER_AGENT = "Mozilla/5.0";


    // HTTP GET request
    public Pesquisa sendGet(String nome, String ano, String geo) throws Exception {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        String url = "http://127.0.0.1:1234/"+nome+"/"+ano+"/"+geo;

        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        // optional default is GET
        con.setRequestMethod("GET");

        //add request header
        con.setRequestProperty("User-Agent", USER_AGENT);

        int responseCode = con.getResponseCode();
        System.out.println("\nSending 'GET' request to URL________________________ : " + url);
        System.out.println("Response Code______________________________ : " + responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        //System.out.println(response.toString());

        JSONObject json= new JSONObject(response.toString());


        Pesquisa pesquisa = new Pesquisa(
                json.getJSONObject("municipio").getString("vegnat_%"), json.getJSONObject("municipio").getString("artif_%"));

        return pesquisa;
    }

}