package com.example.victor.myapplication;

import android.app.Activity;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;





public class MainActivity extends Activity {

    private ModelAndroid model = ModelAndroid.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickSearch(View view) throws Exception {
        Spinner sNome = findViewById(R.id.nome);
        Spinner sAno = findViewById(R.id.ano);
        Spinner sGeo = findViewById(R.id.geo);
        TextView resultArea = findViewById(R.id.result);

        String nome = String.valueOf(sNome.getSelectedItem());
        String ano = String.valueOf(sAno.getSelectedItem());
        String geo = String.valueOf(sGeo.getSelectedItem());

        Pesquisa result = model.getPesquisa(nome, ano, geo);

        StringBuilder finalResult = new StringBuilder();

        if (result != null) {
            finalResult.append(result.getVegnat());
            resultArea.setText(finalResult);
        } else {
            resultArea.setText("Sorry...");
        }
    }
}
